# Campus Care — Vercel-ready Flask app

This version uses Vercel's current zero-configuration Flask deployment support.

## Repository layout

- `app.py` — Flask application and routes
- `requirements.txt` — Python dependencies
- `.gitignore` — local files to ignore

## Vercel

Set **Application Preset** to **Flask** and leave **Root Directory** as `./`.
Leave Build Command and Output Directory at their defaults. Vercel now recognizes Flask apps directly; an `api/` folder or custom `vercel.json` is not required.

Set `SECRET_KEY` in Vercel Environment Variables to a long random value for production.

## Important storage note

Vercel's writable filesystem is temporary. This version uses `/tmp` while running on Vercel so the app can operate, but SQLite data and uploaded images are not durable. For permanent student/complaint data, connect the app to a managed PostgreSQL database and object storage.
